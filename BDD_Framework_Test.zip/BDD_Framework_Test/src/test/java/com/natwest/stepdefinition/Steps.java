package com.natwest.stepdefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Steps {
	@Given("user is on the homepage of PHP Travels")				
    public void user_is_on_the_homepage_of_PHP_Travels() throws Throwable							
    {		
        System.out.println("This Step open the Firefox and launch the application.");					
    }		

    @When("user clicks on the pricing button")					
    public void user_clicks_on_the_pricing_button() throws Throwable 							
    {		
       System.out.println("This step enter the Username and Password on the login page.");					
    }		

    @Then("user is able to see the courses with respective fees")					
    public void user_is_able_to_see_the_courses_with_respective_fees() throws Throwable 							
    {    		
        System.out.println("This step click on the Reset button.");					
    }		

}