
package com.natwest.testrunner;
import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;		

@RunWith(Cucumber.class)				
@CucumberOptions(features={"/BDD_Framework_Test/Features"}, glue = {"com.natwest.stepdefinition"}, plugin= {"pretty"})
public class Runner {
	
		

}
