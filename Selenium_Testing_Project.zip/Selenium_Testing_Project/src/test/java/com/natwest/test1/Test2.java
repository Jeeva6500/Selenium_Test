package com.natwest.test1;

import java.time.Duration;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Test2 extends JunitTest{

	@Test
	public void Test2() {
		
		String url2 = "https://phptravels.com/demo/";
		//WebDriver driver = new ChromeDriver();
		
		driver.get(url2);
		String expectedText = "PHPTRAVELS";

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		
		WebElement pageLoad = driver.findElement(By.id("PHPTRAVELS"));
		System.out.println(pageLoad.getText());
		//String b = pageLoad.getText();
		
		if (pageLoad.getText().equalsIgnoreCase(expectedText)) {
			//if ("PHPTRAVELS".equalsIgnoreCase(driver.findElement(By.id("PHPTRAVELS")).getText())) {
		
		//if (a.equalsIgnoreCase(b)) {
			System.out.println("Text available");
			//}
		}
		driver.close();
	}
}
