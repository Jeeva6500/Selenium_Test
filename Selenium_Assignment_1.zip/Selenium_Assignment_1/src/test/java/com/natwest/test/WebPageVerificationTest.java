package com.natwest.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebPageVerificationTest extends MainMethod{
	@Test
	public void WebPageTest() throws IOException {
			
		//WebDriver driver = new ChromeDriver();
		
		String url1 = " https://phptravels.com/";
		driver.get(url1);
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(20));
		
		//String url2 = "https://phptravels.com/pricing/";
		//JavascriptExecutor price123 = (JavascriptExecutor) driver;
		//price123.executeScript("Window.scrollBy(100,50)");
		
		
		WebElement demo = driver.findElement(By.xpath("//div[@class='df jcc gap1']//a[@class= 'btn-outline-dark df aic gap2']"));
		System.out.println(demo.getText());
		WebElement price = driver.findElement(By.xpath("//div[@class='df jcc gap1']//a[@class= 'btn-outline-white']"));
		System.out.println(price.getText());
		
		
		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(20));
		
		String url3 = "https://link.phptravels.com/agency/";
		driver.get(url3);
		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement price1 = driver.findElement(By.xpath("//div[@class='order-total text-right']//span[@class= 'price-amount']"));
		
		
		
		System.out.println(price.getText());
		//String price1 = "10,050.23";
		
		//WebElement totalPricing = driver.findElement(By.className("price-amount"));
		
		//if (price1.equalsIgnoreCase(driver.findElement(By.className("price-amount")).getText())) {
		//if (price1.equalsIgnoreCase(driver.findElement(By.className("order-total text-right")).getCssValue(By.className("price-amount").toString()))) {
		//	System.out.println(price1);
		//}
		
			driver.close();
	}


	}



