package com.natwest.Test;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainMethod {

WebDriver driver = new ChromeDriver();
	
	public static void main(String[] args) {
		
		Result result1 = JUnitCore.runClasses(WebPageTest.class);
		System.out.println(result1.wasSuccessful());

}
}
