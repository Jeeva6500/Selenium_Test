package com.natwest.test1;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class Test1 extends JunitTest{
	
	@Test
	public void Test1() throws IOException {
		
		String url1 = "https://www.w3schools.com/";
		//WebDriver driver = new ChromeDriver();
		
		FileInputStream fs = new FileInputStream("C:\\Users\\RBS\\Desktop\\Final Project Groups.xlsx"); //excel path
		XSSFWorkbook wb = new XSSFWorkbook(fs);  // creating object
		XSSFSheet st = wb.getSheetAt(0);               // select excel file sheet through index position
		XSSFSheet st1 = wb.getSheet("Project Groups"); //select excel file sheet through sheet name
		
		
		driver.get(url1);
		
		WebElement loginButton = driver.findElement(By.id("w3loginbtn"));
		loginButton.click();
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		
		//WebElement loginButton2 = driver.findElement(By.className("Button_button__URNp+ Button_primary__d2Jt3 Button_fullwidth__0HLEu"));
		//
		//if (loginButton2.isDisplayed()) {
		//	System.out.println("Web page loaded");
		//} else {
		//	
		//}
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("modalusername")));
		WebElement textField = driver.findElement(By.id("modalusername"));
		if (textField.isDisplayed()) {		
		System.out.println("Web page loaded");
		String email = st1.getRow(1).getCell(2).getStringCellValue(); //get email id from sheet of excel.
		
		textField.sendKeys(email); // sendKeys for sending the data // excel should be closed while running
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}
		else {
			System.out.println("Page not loaded");
		}
	
		driver.close();
	}

}
