package com.natwest.test1;
import org.junit.runner.JUnitCore;		
import org.junit.runner.Result;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JunitTest {
	
	WebDriver driver = new ChromeDriver();
	
	public static void main(String[] args) {
		
		Result result1 = JUnitCore.runClasses(Test1.class);
		System.out.println(result1.wasSuccessful());
		
		Result result2 = JUnitCore.runClasses(Test2.class);
		System.out.println(result2.wasSuccessful());
		
		
		
	}
	

}
