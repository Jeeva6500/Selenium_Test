package com.natwest.test1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class TextFileTest extends JunitTest{
@Test
	public void TestFileTest() throws IOException {
		
		//String url1 = "https://www.w3schools.com/";
		
		File file1 = new File("C:\\Jeeva1\\Selenium\\data.txt");
		FileReader fr = new FileReader(file1);
		long length = file1.length();
		
		for(long i = 0; i<length; i++) {
			System.out.println((char)fr.read());
		}
		
		//driver.get(url1);
		
		//WebElement loginButton = driver.findElement(By.id("w3loginbtn"));
		//loginButton.click();
		
		//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		
		
		//wait.until(ExpectedConditions.presenceOfElementLocated(By.id("modalusername")));
		//WebElement textField = driver.findElement(By.id("modalusername"));
		//if (textField.isDisplayed()) {		
		//System.out.println("Web page loaded");
		//String email = st1.getRow(1).getCell(2).getStringCellValue(); //get email id from sheet of excel.
		
		//textField.sendKeys(email); // sendKeys for sending the data // excel should be closed while running
		
		//}
		//else {
		//	System.out.println("Page not loaded");
		//}
	
		//driver.close();
	}

}

